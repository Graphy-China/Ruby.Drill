require 'test_helper'

class ShipsHelperTest < ActionView::TestCase
end
