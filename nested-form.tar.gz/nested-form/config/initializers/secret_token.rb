# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
NestedForm::Application.config.secret_token = 'ffa7717d1a8bb3b64c40772565ec849ffd929390953f249a2dccddd517777cd82913bd2a95894154de402e2ecab5d26d62c7668814368a3739c61b0e5094c40a'
