require 'test_helper'

class CustomersNotesTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
