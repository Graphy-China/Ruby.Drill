require 'test_helper'

class DashboardHelperTest < ActionView::TestCase
end
