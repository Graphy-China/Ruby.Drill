require 'test_helper'

class CountriesHelperTest < ActionView::TestCase
end
