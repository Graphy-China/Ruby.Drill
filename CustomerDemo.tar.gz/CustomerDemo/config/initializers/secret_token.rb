# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CustomeR::Application.config.secret_token = 'cc517a79fcd381cdfee39716296adf172358cf0614dbec0ff8313c1b3154213542e7efad89a87c8873218012b2e20fb400a87f89a9c3756133631702aed3d333'
