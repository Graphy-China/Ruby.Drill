class DashboardController < ApplicationController

end
